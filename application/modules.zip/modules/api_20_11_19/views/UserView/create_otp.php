<?php
if(!$_REQUEST) {
    $error      = true;
    $code       = 99;
    $msg        = 'Please Send Data in Key and Value Pair';
    $data       = new stdClass();
}else{
    $required = array ( 'email');
    $model                          = new User_model();
    $headers                        = getallheaders();
    $lang                           = isset($headers['Lang']) ? $headers['Lang'] : "en";
    $checkRequired=$model->check_requiredField($_REQUEST,$required);
    if($checkRequired['status']){
        $error      = true;
        $code       = 98;
        $msg        = $checkRequired['field'].' field is required.';
        $data       = new stdClass();
    }else{
        //	$model->printRecord("register_req", $_REQUEST);
        $_REQUEST['otp']                        = rand(1000,9999);
        $sendOtp                                = $model->check_email($_REQUEST);
        if($sendOtp){
            $createOtp                          = $model->createOtp($_REQUEST);
            if($createOtp){
                $error                          = false;
                $code                           = 200;
                $msg                            = 'Otp send to your registered Email-Id';
                $data                           = array('otp'=>strval($_REQUEST['otp']));
            }else{
                $error                          = true;
                $code                           = 202;
                $msg                            = 'Some error found.';
                $data                           = new stdClass();
            }
            
        }else{
            $error                              = true;
            $code                               = 201;
            $msg                                = 'This Email is not registered.';
            $data                               = new stdClass();
        }
    }
}
echo json_encode(array('error'=>$error,'error_code'=>$code,'message'=>$msg,'data'=>$data));
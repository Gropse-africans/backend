                <footer class="footer ptb-20">

                  <div class="row">

                    <div class="col-md-12 text-center">

                      <div class="copy_right">

                        <p>

                          2019 ©  All Right Reserved by<a href="#"> Africans Supermarket</a>
                        </p>

                      </div>

                      <a id="back-to-top" href="#">

                        <i class="fa fa-arrow-up"></i>

                      </a>

                    </div>

                  </div>

                </footer>

          </div>

          <script src="<?php echo base_url('assets/admin/js/jquery.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/popper.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/bootstrap.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/Chart.bundle.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/utils.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/chart.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js'); ?>"></script>

             <script src="<?php echo base_url('assets/admin/js/dataTables.bootstrap4.min.js'); ?>"></script>

             <script src="<?php echo base_url('assets/admin/js/chart.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/jquery.dcjqaccordion.2.7.js'); ?>"></script>

            <script src="<?php echo base_url('assets/admin/js/moment.min.js'); ?>"></script>
            <script src="<?php echo base_url('assets/admin/js/fullcalendar.js'); ?>"></script>
            <script src="<?php echo base_url('assets/admin/js/calendar-list-init.js'); ?>"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
 
            <script src="<?php echo base_url('assets/admin/js/custom.js'); ?>"></script>

	</body>

</html>
<div id="information-information" class="container">
    <ul class="breadcrumb">
        <li><a href="<?php echo base_url('');?>"><i class="fa fa-home"></i></a></li>
        <li><a>Delivery Information</a></li>
    </ul>
    <div class="row">
        <?=$this->load->view('user_side_link')?>
        <div id="content" class="col-sm-9">
            <h1 class="page-title">Delivery Information</h1>
            <div class="aboutus">
                <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
                <div class="about-content"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div class="aboutus">
                <h3>Certain circumstances and owing to the claims of duty or the obligations</h3>
                <div class="about-content"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div class="aboutus">
                <h3>Integer ultrices laoreet nunc in gravida</h3>
                <div class="about-content"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
        </div>
    </div>
</div>
<aside id="column-left" class="col-sm-3 hidden-xs">
    <div class="box">
        <div class="box-heading">Account</div>
        <div class="list-group">
            <a href="<?php echo base_url('my-account'); ?>" class="list-group-item">My Account </a>
            <a href="<?php echo base_url('change-password'); ?> " class="list-group-item">Change Password</a>
            <!--<a href="<?php echo base_url('my-address'); ?> " class="list-group-item">My Address</a>-->
            <a href="<?php echo base_url('wishlist'); ?> " class="list-group-item">My Wishlist</a>
            <!--<a href="<?php echo base_url('order-history'); ?> " class="list-group-item">Order History</a>-->
            <!--<a href="<?php echo base_url('my-transaction'); ?> " class="list-group-item">My Transactions</a>-->
            <a href="<?php echo base_url('logout'); ?> " class="list-group-item">Logout</a>
        </div>
    </div>
</aside>
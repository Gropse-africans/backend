<aside id="column-left" class="col-sm-3 hidden-xs">
    <div class="box">
        <div class="box-heading">Information</div>
        <div class="list-group">
            <a class="list-group-item" href="<?php echo base_url('about-us'); ?>">About Us </a>
            <a class="list-group-item" href="<?php echo base_url('delivery-information'); ?>">Delivery Information</a>
            <a class="list-group-item" href="<?php echo base_url('privacy-policy'); ?>">Privacy Policy </a>
            <a class="list-group-item" href="<?php echo base_url('term-and-condition'); ?>">Terms &amp; Conditions </a>
            <!--<a class="list-group-item" href="<?php echo base_url('contact-us'); ?>">Contact Us </a>-->
            <!--<a class="list-group-item" href="<?php echo base_url('site-map'); ?>">Site Map </a>-->
        </div>
    </div>

</aside>